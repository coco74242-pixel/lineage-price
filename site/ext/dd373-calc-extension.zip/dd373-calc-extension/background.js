/* global importScripts, DD373Calc, chrome */
"use strict";

importScripts("calc.js");

async function refreshRate() {
  try {
    var rate = await DD373Calc.fetchRate();
    await chrome.storage.local.set({
      bankRate: rate,
      bankRateAt: Date.now(),
      bankRateError: null
    });
    return { ok: true, rate: rate };
  } catch (err) {
    var msg = String((err && err.message) || err);
    var stored = await chrome.storage.local.get(["bankRate"]);
    await chrome.storage.local.set({ bankRateError: msg });
    return { ok: false, error: msg, rate: stored.bankRate || null };
  }
}

chrome.runtime.onMessage.addListener(function (msg, _sender, sendResponse) {
  if (msg && msg.type === "refreshRate") {
    refreshRate().then(sendResponse).catch(function (err) {
      sendResponse({ ok: false, error: String((err && err.message) || err) });
    });
    return true;
  }
});

chrome.runtime.onInstalled.addListener(function () {
  refreshRate();
});

chrome.runtime.onStartup.addListener(function () {
  refreshRate();
});
