/* global importScripts, DD373Calc, chrome */
"use strict";

importScripts("calc.js");

var RATE_URL = "https://coco74242-pixel.github.io/lineage-price/dd373/rate.csv";

async function refreshRate() {
  try {
    var res = await fetch(RATE_URL, { cache: "no-store" });
    if (!res.ok) throw new Error("HTTP " + res.status);
    var text = await res.text();
    var rate = DD373Calc.parseRate(text);
    if (rate == null) throw new Error("格式不正確");
    await chrome.storage.local.set({
      bankRate: rate,
      bankRateAt: Date.now(),
      bankRateError: null
    });
    return { ok: true, rate: rate };
  } catch (err) {
    var msg = String((err && err.message) || err);
    await chrome.storage.local.set({ bankRateError: msg });
    var stored = await chrome.storage.local.get(["bankRate"]);
    return { ok: false, error: msg, rate: stored.bankRate || null };
  }
}

chrome.runtime.onMessage.addListener(function (msg, _sender, sendResponse) {
  if (msg && msg.type === "refreshRate") {
    refreshRate().then(sendResponse);
    return true;
  }
});

chrome.runtime.onInstalled.addListener(function () {
  refreshRate();
});

chrome.runtime.onStartup.addListener(function () {
  refreshRate();
});
