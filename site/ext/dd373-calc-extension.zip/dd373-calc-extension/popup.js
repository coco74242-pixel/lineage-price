"use strict";
DD373UI.mount(document.getElementById("app"), { panel: false });
