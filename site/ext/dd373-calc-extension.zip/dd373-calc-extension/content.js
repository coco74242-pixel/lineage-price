"use strict";

(function () {
  if (window.__dd373CalcMounted) return;
  window.__dd373CalcMounted = true;

  var HOST_ID = "dd373-calc-host";
  if (document.getElementById(HOST_ID)) return;

  var host = document.createElement("div");
  host.id = HOST_ID;
  host.setAttribute("data-dd373-calc", "1");
  Object.assign(host.style, {
    all: "initial",
    position: "fixed",
    zIndex: "2147483646",
    right: "16px",
    bottom: "16px",
    width: "auto",
    height: "auto",
    margin: "0",
    padding: "0",
    border: "0",
    background: "transparent"
  });
  (document.documentElement || document.body).appendChild(host);

  var shadow = host.attachShadow({ mode: "open" });
  var ui = null;
  var dragging = false;
  var dragMoved = false;
  var startX = 0, startY = 0, startLeft = 0, startTop = 0;

  function clamp(n, min, max) {
    return Math.max(min, Math.min(max, n));
  }

  function applyPos(pos) {
    if (!pos || !isFinite(pos.left) || !isFinite(pos.top)) return;
    var w = host.offsetWidth || 44;
    var h = host.offsetHeight || 44;
    var left = clamp(pos.left, 8, Math.max(8, window.innerWidth - w - 8));
    var top = clamp(pos.top, 8, Math.max(8, window.innerHeight - h - 8));
    host.style.left = left + "px";
    host.style.top = top + "px";
    host.style.right = "auto";
    host.style.bottom = "auto";
  }

  function currentPos() {
    var r = host.getBoundingClientRect();
    return { left: r.left, top: r.top };
  }

  chrome.storage.local.get(["panelCollapsed", "panelPos"], function (data) {
    ui = DD373UI.mount(shadow, {
      panel: true,
      startCollapsed: data.panelCollapsed !== false, // 預設收合，少擋畫面
      onCollapse: function (collapsed) {
        chrome.storage.local.set({ panelCollapsed: collapsed });
        // 收合後維持同一角，避免尺寸變了跑出畫面
        requestAnimationFrame(function () { applyPos(currentPos()); });
      }
    });

    if (data.panelPos) applyPos(data.panelPos);

    function onDown(ev) {
      if (ev.button != null && ev.button !== 0) return;
      if (ev.target && ev.target.closest && ev.target.closest("button, input, label")) return;
      var r = host.getBoundingClientRect();
      dragging = true;
      dragMoved = false;
      startX = ev.clientX;
      startY = ev.clientY;
      startLeft = r.left;
      startTop = r.top;
      ev.preventDefault();
    }

    function onMove(ev) {
      if (!dragging) return;
      var dx = ev.clientX - startX;
      var dy = ev.clientY - startY;
      if (Math.abs(dx) + Math.abs(dy) > 3) dragMoved = true;
      applyPos({ left: startLeft + dx, top: startTop + dy });
    }

    function onUp() {
      if (!dragging) return;
      dragging = false;
      if (dragMoved) chrome.storage.local.set({ panelPos: currentPos() });
    }

    if (ui.header) {
      ui.header.addEventListener("mousedown", onDown);
    }
    if (ui.fab) {
      ui.fab.addEventListener("mousedown", onDown);
      ui.fab.addEventListener("click", function (ev) {
        if (dragMoved) ev.stopImmediatePropagation();
      }, true);
    }
    window.addEventListener("mousemove", onMove, true);
    window.addEventListener("mouseup", onUp, true);

    function maybeFillFromSelection() {
      var sel = window.getSelection && window.getSelection();
      var text = sel ? String(sel.toString() || "") : "";
      var n = DD373Calc.parseSelectedPrice(text);
      if (n == null) return;
      ui.setRmb(n);
    }

    document.addEventListener("mouseup", function () {
      setTimeout(maybeFillFromSelection, 0);
    }, true);
    document.addEventListener("keyup", function (ev) {
      if (ev.key === "Shift" || ev.shiftKey) maybeFillFromSelection();
    }, true);
  });

  // 避免滑動面板時背後的網頁跟著滾
  host.addEventListener("wheel", function (e) { e.stopPropagation(); }, { passive: true });
  host.addEventListener("touchmove", function (e) { e.stopPropagation(); }, { passive: true });
})();
