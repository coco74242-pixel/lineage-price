/**
 * 共用介面：瀏覽器彈出視窗、以及 dd373 頁面的浮動面板都用這份。
 * 只讀自己的 chrome.storage，匯率只向官方公開的 rate.csv 抓取。
 */
(function (root) {
  "use strict";

  var CSS = [
    ":host, * { box-sizing: border-box; }",
    ".wrap { font-family: 'PingFang TC','Noto Sans TC','Source Han Sans TC','Microsoft JhengHei',ui-sans-serif,system-ui,sans-serif;",
    "  color: #1c1917; font-size: 13px; line-height: 1.4; width: 300px; }",
    ".panel { background: #fffdf8; border: 1px solid #e7e0d6; border-radius: 10px;",
    "  box-shadow: 0 8px 24px rgba(28,25,23,.16); overflow: hidden; }",
    ".hd { display: flex; align-items: center; gap: 6px; padding: 7px 8px 7px 10px;",
    "  background: #0f766e; color: #fff; cursor: default; user-select: none; }",
    ".hd.drag { cursor: move; }",
    ".hd h1 { font-size: 13px; margin: 0; font-weight: 700; flex: 1; letter-spacing: .02em; }",
    ".hd button { background: transparent; border: 0; color: #fff; font-size: 16px; line-height: 1;",
    "  width: 24px; height: 24px; border-radius: 4px; cursor: pointer; padding: 0; }",
    ".hd button:hover { background: rgba(255,255,255,.18); }",
    ".bd { padding: 10px 10px 8px; }",
    "label.lbl { display: block; font-size: 12px; color: #78716c; margin: 0 0 4px; }",
    ".input-row { display: flex; align-items: center; gap: 6px; margin-bottom: 10px; }",
    ".input-row .pre, .input-row .post { color: #57534e; white-space: nowrap; font-weight: 600; }",
    "input[type=text], input[type=number] { flex: 1; min-width: 0; font-size: 16px; font-weight: 700;",
    "  padding: 5px 8px; border: 1px solid #e7e0d6; border-radius: 6px; text-align: right;",
    "  background: #fff; color: #1c1917; font-variant-numeric: tabular-nums; width: 100%; }",
    "input[type=text]:focus, input[type=number]:focus { outline: 2px solid #0f766e; outline-offset: 1px; border-color: #0f766e; }",
    "input.rate-in { font-size: 13px; font-weight: 600; padding: 3px 6px; width: 5.5em; flex: none; }",
    ".rate { background: #f4f1ea; border-radius: 8px; padding: 7px 8px; margin-bottom: 10px; font-size: 12px; }",
    ".rate .row { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }",
    ".rate b { font-variant-numeric: tabular-nums; }",
    ".rate .meta { color: #78716c; margin-top: 3px; }",
    ".rate .err { color: #b91c1c; margin-top: 3px; }",
    ".rate button { background: #fff; color: #0f766e; border: 1px solid #0f766e; border-radius: 6px;",
    "  padding: 2px 8px; font-weight: 700; cursor: pointer; font-size: 12px; }",
    ".rate button:disabled { opacity: .6; cursor: default; }",
    ".chk { display: flex; align-items: center; gap: 4px; margin-top: 6px; color: #44403c; }",
    ".chk input { margin: 0; }",
    ".out { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 8px; }",
    ".card { background: #f4f1ea; border-radius: 8px; padding: 7px 8px; }",
    ".card .k { font-size: 11.5px; color: #78716c; }",
    ".card .v { font-size: 20px; font-weight: 800; font-variant-numeric: tabular-nums; color: #0f766e; margin-top: 1px; }",
    ".card .v .u { font-size: 12px; font-weight: 600; color: #57534e; margin-left: 2px; }",
    ".card .v.empty { color: #a8a29e; font-size: 16px; font-weight: 600; }",
    ".note { font-size: 11px; color: #78716c; margin: 0; }",
    ".flash { animation: flash 0.7s ease; }",
    "@keyframes flash { 0% { box-shadow: 0 0 0 0 rgba(15,118,110,.45); } 100% { box-shadow: 0 0 0 8px rgba(15,118,110,0); } }",
    ".fab { width: 44px; height: 44px; border-radius: 50%; border: 0; cursor: pointer;",
    "  background: #0f766e; color: #fffdf8; font-weight: 800; font-size: 16px;",
    "  box-shadow: 0 6px 18px rgba(15,118,110,.4); font-family: inherit; }",
    ".fab:hover { background: #115e59; }",
    ".hidden { display: none !important; }"
  ].join("\n");

  // popup 掛在普通 div 上，div 沒有 getElementById（只有 document / ShadowRoot 才有）
  function findEl(root, id) {
    if (!root) return null;
    if (typeof root.getElementById === "function") {
      var byId = root.getElementById(id);
      if (byId) return byId;
    }
    if (typeof root.querySelector === "function") {
      return root.querySelector("#" + id);
    }
    return null;
  }
  function $(root, id) { return findEl(root, id); }

  function fmtTime(ts) {
    if (!ts) return "";
    return new Date(ts).toLocaleString("zh-Hant-TW", {
      timeZone: "Asia/Taipei",
      hour12: false,
      month: "numeric",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    }) + "（台北時間）";
  }

  function effectiveRate(state) {
    return DD373Calc.resolveRate(state).rate;
  }

  function rateLabel(resolved, state) {
    var n = resolved.rate;
    if (resolved.source === "manual") return n + "（手動）";
    if (resolved.source === "default") return n + "（內建備用）";
    return String(n);
  }

  function mount(target, options) {
    options = options || {};
    var isPanel = !!options.panel;
    var hostDoc = target.nodeType === 11 ? target : target.ownerDocument || document;

    var style = hostDoc.createElement("style");
    style.textContent = CSS;
    target.appendChild(style);

    var wrap = hostDoc.createElement("div");
    wrap.className = "wrap";
    wrap.innerHTML =
      '<button type="button" class="fab hidden" id="fab" title="展開天幣換算" aria-label="展開天幣換算">金</button>' +
      '<div class="panel" id="panel">' +
        '<div class="hd' + (isPanel ? " drag" : "") + '" id="hd">' +
          "\n<h1>DD373 天幣換算</h1>" +
          (isPanel ? '<button type="button" id="btnMin" title="收合" aria-label="收合">–</button>' : "") +
        "</div>" +
        '<div class="bd">' +
          '<label class="lbl" for="rmb">1万金 等於多少人民幣</label>' +
          '<div class="input-row">' +
            '<span class="pre">1万金＝</span>' +
            '<input id="rmb" type="text" inputmode="decimal" autocomplete="off" placeholder="x.xxx" aria-label="1万金等於多少人民幣">' +
            '<span class="post">元</span>' +
          "</div>" +
          '<div class="rate">' +
            '<div class="row">臺銀匯率（現金賣出） <b id="rateVal">—</b>' +
              '<button type="button" id="btnRate">更新匯率</button></div>' +
            '<div class="meta" id="rateMeta"></div>' +
            '<div class="err hidden" id="rateErr"></div>' +
            '<label class="chk"><input type="checkbox" id="useManual"> 改用手動匯率</label>' +
            '<div class="row" id="manualRow" style="margin-top:6px;display:none">' +
              '<input class="rate-in" id="manualRate" type="text" inputmode="decimal" autocomplete="off" aria-label="手動匯率">' +
            "</div>" +
          "</div>" +
          '<div class="out">' +
            '<div class="card"><div class="k">台幣／1万金</div><div class="v empty" id="twd">—</div></div>' +
            '<div class="card"><div class="k">成本 1台幣</div><div class="v empty" id="gold">—</div></div>' +
          "</div>" +
          '<p class="note">台幣＝人民幣×匯率；1台幣金量＝10000÷（人民幣×匯率），與成本表 D 欄相同。在本頁反白價格可自動填入。資料只存在你的瀏覽器。</p>' +
        "</div>" +
      "</div>";
    target.appendChild(wrap);

    var state = {
      bankRate: null,
      bankRateAt: null,
      bankRateError: null,
      useManualRate: false,
      manualRate: "",
      lastRmb: ""
    };
    var collapsed = !!options.startCollapsed;

    function setCollapsed(v) {
      collapsed = !!v;
      $(target, "fab").classList.toggle("hidden", !collapsed);
      $(target, "panel").classList.toggle("hidden", collapsed);
      if (options.onCollapse) options.onCollapse(collapsed);
    }

    function renderRate() {
      var resolved = DD373Calc.resolveRate(state);
      $(target, "rateVal").textContent = rateLabel(resolved, state);
      var meta = [];
      if (resolved.source === "default") {
        meta.push("尚未抓到臺銀匯率，先用內建備用值 " + DD373Calc.DEFAULT_RATE);
      } else if (state.bankRateAt) {
        meta.push("臺銀 " + fmtTime(state.bankRateAt));
      }
      $(target, "rateMeta").textContent = meta.join(" · ");
      var errEl = $(target, "rateErr");
      if (state.bankRateError && resolved.source === "default") {
        errEl.textContent = "匯率讀取失敗：" + state.bankRateError + "。已改用內建備用值 " + DD373Calc.DEFAULT_RATE + "，仍可計算。";
        errEl.classList.remove("hidden");
      } else if (state.bankRateError) {
        errEl.textContent = "這次更新失敗：" + state.bankRateError + "。仍用上次的 " + state.bankRate + "。";
        errEl.classList.remove("hidden");
      } else {
        errEl.textContent = "";
        errEl.classList.add("hidden");
      }
      $(target, "useManual").checked = !!state.useManualRate;
      $(target, "manualRow").style.display = state.useManualRate ? "flex" : "none";
      if (state.manualRate !== "" && $(target, "manualRate").value !== String(state.manualRate)) {
        $(target, "manualRate").value = state.manualRate;
      }
    }

    function renderCalc() {
      var rmb = DD373Calc.parseRmb($(target, "rmb").value);
      var rate = effectiveRate(state);
      var twdEl = $(target, "twd");
      var goldEl = $(target, "gold");
      var out = rmb != null && rate != null ? DD373Calc.convert(rmb, rate) : null;
      if (!out) {
        twdEl.className = "v empty";
        goldEl.className = "v empty";
        twdEl.textContent = "—";
        goldEl.textContent = "—";
        return;
      }
      twdEl.className = "v";
      goldEl.className = "v";
      twdEl.innerHTML = out.twdText + '<span class="u">元</span>';
      goldEl.innerHTML = out.goldText + '<span class="u">金</span>';
    }

    function render() {
      renderRate();
      renderCalc();
    }

    async function loadState() {
      var data = await chrome.storage.local.get([
        "bankRate", "bankRateAt", "bankRateError",
        "useManualRate", "manualRate", "lastRmb"
      ]);
      state.bankRate = data.bankRate != null ? Number(data.bankRate) : null;
      state.bankRateAt = data.bankRateAt || null;
      state.bankRateError = data.bankRateError || null;
      state.useManualRate = !!data.useManualRate;
      state.manualRate = data.manualRate != null ? String(data.manualRate) : "";
      if (data.lastRmb != null && data.lastRmb !== "" && !$(target, "rmb").value) {
        $(target, "rmb").value = String(data.lastRmb);
      }
      render();
    }

    function savePartial(obj) {
      chrome.storage.local.set(obj);
    }

    async function tryBackgroundRefresh() {
      try {
        if (!chrome.runtime || !chrome.runtime.sendMessage) return null;
        var result = await chrome.runtime.sendMessage({ type: "refreshRate" });
        return result || null;
      } catch (e) {
        return { ok: false, error: String((e && e.message) || e) };
      }
    }

    async function tryDirectRefresh() {
      var rate = await DD373Calc.fetchRate();
      await chrome.storage.local.set({
        bankRate: rate,
        bankRateAt: Date.now(),
        bankRateError: null
      });
      return { ok: true, rate: rate };
    }

    async function refreshRate() {
      var btn = $(target, "btnRate");
      if (btn) {
        btn.disabled = true;
        btn.textContent = "更新中…";
      }
      var result = await tryBackgroundRefresh();
      if (!result || !result.ok) {
        try {
          result = await tryDirectRefresh();
        } catch (e) {
          var msg = (result && result.error) || String((e && e.message) || e) || "無法連線";
          await chrome.storage.local.set({ bankRateError: msg });
          state.bankRateError = msg;
        }
      }
      await loadState();
      if (btn) {
        btn.disabled = false;
        btn.textContent = "更新匯率";
      }
    }

    $(target, "rmb").addEventListener("input", function () {
      savePartial({ lastRmb: $(target, "rmb").value });
      renderCalc();
    });
    $(target, "useManual").addEventListener("change", function () {
      state.useManualRate = $(target, "useManual").checked;
      if (state.useManualRate && !state.manualRate && state.bankRate != null) {
        state.manualRate = String(state.bankRate);
        $(target, "manualRate").value = state.manualRate;
      }
      savePartial({ useManualRate: state.useManualRate, manualRate: state.manualRate });
      render();
    });
    $(target, "manualRate").addEventListener("input", function () {
      state.manualRate = $(target, "manualRate").value;
      savePartial({ manualRate: state.manualRate });
      render();
    });
    $(target, "btnRate").addEventListener("click", function () { refreshRate(); });

    if (isPanel) {
      $(target, "btnMin").addEventListener("click", function (e) {
        e.stopPropagation();
        setCollapsed(true);
      });
      $(target, "fab").addEventListener("click", function (e) {
        e.stopPropagation();
        setCollapsed(false);
      });
      setCollapsed(collapsed);
    }

    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area !== "local") return;
      var keys = ["bankRate", "bankRateAt", "bankRateError", "useManualRate", "manualRate"];
      var hit = keys.some(function (k) { return k in changes; });
      if (hit) loadState();
    });

    loadState().then(function () {
      var stale = !state.bankRate || !state.bankRateAt || (Date.now() - state.bankRateAt > 5 * 60 * 1000);
      if (stale) refreshRate();
    });

    return {
      setRmb: function (n) {
        if (n == null || !isFinite(n)) return;
        var el = $(target, "rmb");
        el.value = String(n);
        savePartial({ lastRmb: el.value });
        renderCalc();
        if (isPanel) setCollapsed(false);
        var panel = $(target, "panel");
        panel.classList.remove("flash");
        void panel.offsetWidth;
        panel.classList.add("flash");
      },
      setCollapsed: setCollapsed,
      isCollapsed: function () { return collapsed; },
      header: $(target, "hd"),
      fab: $(target, "fab")
    };
  }

  root.DD373UI = { mount: mount, styles: CSS, findEl: findEl };
  if (typeof module !== "undefined" && module.exports) {
    module.exports = root.DD373UI;
  }
})(typeof globalThis !== "undefined" ? globalThis : this);
