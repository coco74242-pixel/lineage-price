/**
 * DD373 天幣換算公式（與成本表 D 欄相同）
 * 台幣／1万金 = 人民幣 × 匯率
 * 成本 1台幣（金）= 10000 ÷（人民幣 × 匯率）
 */
(function (root) {
  "use strict";

  var RATE_MIN = 3;
  var RATE_MAX = 7;

  function parseRate(text) {
    if (text == null) return null;
    var n = Number(String(text).replace(/^\uFEFF/, "").trim());
    if (!isFinite(n) || n <= RATE_MIN || n >= RATE_MAX) return null;
    return n;
  }

  function parseRmb(text) {
    if (text == null) return null;
    var s = String(text).replace(/,/g, "").replace(/\s/g, "");
    if (!s) return null;
    var m = s.match(/(?:1[万萬]金\s*[=＝:：]*)?(\d+(?:\.\d+)?)/);
    if (!m) return null;
    var n = Number(m[1]);
    if (!isFinite(n) || n <= 0) return null;
    return n;
  }

  /** 反白價格：只接受像 0.328、0.328元、1万金=0.328元 這種人民幣單價 */
  function parseSelectedPrice(text) {
    if (text == null) return null;
    var raw = String(text).trim();
    if (!raw || raw.length > 40) return null;
    var n = parseRmb(raw);
    if (n == null) return null;
    if (n >= 20) return null;
    return n;
  }

  function convert(rmb, rate) {
    if (!isFinite(rmb) || rmb <= 0 || !isFinite(rate) || rate <= 0) return null;
    var twd = rmb * rate;
    var gold = 10000 / twd;
    return {
      twd: twd,
      gold: gold,
      twdText: twd.toFixed(2),
      goldText: Math.round(gold).toLocaleString("zh-Hant-TW")
    };
  }

  var api = {
    RATE_MIN: RATE_MIN,
    RATE_MAX: RATE_MAX,
    parseRate: parseRate,
    parseRmb: parseRmb,
    parseSelectedPrice: parseSelectedPrice,
    convert: convert
  };

  if (typeof module !== "undefined" && module.exports) {
    module.exports = api;
  }
  root.DD373Calc = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
