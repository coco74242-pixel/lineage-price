/**
 * DD373 天幣換算公式（與成本表 D 欄相同）
 * 台幣／1万金 = 人民幣 × 匯率
 * 成本 1台幣（金）= 10000 ÷（人民幣 × 匯率）
 */
(function (root) {
  "use strict";

  var RATE_MIN = 3;
  var RATE_MAX = 7;
  var DEFAULT_RATE = 5.008;
  var RATE_URL = "https://coco74242-pixel.github.io/lineage-price/dd373/rate.csv";

  function parseRate(text) {
    if (text == null) return null;
    var raw = String(text).replace(/^\uFEFF/, "").trim();
    if (!raw) return null;
    // 只要第一行數字，避免誤把 HTML 錯誤頁當成匯率
    var first = raw.split(/\r?\n/, 1)[0].trim().replace(/,+$/, "");
    var n = Number(first);
    if (!isFinite(n) || n <= RATE_MIN || n >= RATE_MAX) return null;
    return n;
  }

  function parseRmb(text) {
    if (text == null) return null;
    var s = String(text).replace(/,/g, "").replace(/\s/g, "");
    if (!s) return null;
    var m = s.match(/(?:1[万萬]金\s*[=＝:：]*)?(\d+(?:\.\d+)?)/);
    if (!m) return null;
    var n = Number(m[1]);
    if (!isFinite(n) || n <= 0) return null;
    return n;
  }

  /** 反白價格：只接受像 0.328、0.328元、1万金=0.328元 這種人民幣單價 */
  function parseSelectedPrice(text) {
    if (text == null) return null;
    var raw = String(text).trim();
    if (!raw || raw.length > 40) return null;
    var n = parseRmb(raw);
    if (n == null) return null;
    if (n >= 20) return null;
    return n;
  }

  function convert(rmb, rate) {
    if (!isFinite(rmb) || rmb <= 0 || !isFinite(rate) || rate <= 0) return null;
    var twd = rmb * rate;
    var gold = 10000 / twd;
    return {
      twd: twd,
      gold: gold,
      twdText: twd.toFixed(2),
      goldText: Math.round(gold).toLocaleString("zh-Hant-TW")
    };
  }

  /**
   * 優先手動匯率，其次已抓到／快取的臺銀匯率，最後用內建備用值。
   * 回傳 { rate, source }，source 為 manual | bank | default
   */
  function resolveRate(state) {
    state = state || {};
    if (state.useManualRate) {
      var m = parseRate(state.manualRate);
      if (m != null) return { rate: m, source: "manual" };
    }
    var b = Number(state.bankRate);
    if (isFinite(b) && b > RATE_MIN && b < RATE_MAX) {
      return { rate: b, source: "bank" };
    }
    return { rate: DEFAULT_RATE, source: "default" };
  }

  async function fetchRate(fetcher) {
    var fn = fetcher || (typeof fetch === "function" ? fetch : null);
    if (!fn) throw new Error("沒有可用的網路函式");
    var res = await fn(RATE_URL, { cache: "no-store" });
    if (!res || !res.ok) throw new Error("HTTP " + ((res && res.status) || "失敗"));
    var text = await res.text();
    var rate = parseRate(text);
    if (rate == null) throw new Error("格式不正確");
    return rate;
  }

  var api = {
    RATE_MIN: RATE_MIN,
    RATE_MAX: RATE_MAX,
    DEFAULT_RATE: DEFAULT_RATE,
    RATE_URL: RATE_URL,
    parseRate: parseRate,
    parseRmb: parseRmb,
    parseSelectedPrice: parseSelectedPrice,
    convert: convert,
    resolveRate: resolveRate,
    fetchRate: fetchRate
  };

  if (typeof module !== "undefined" && module.exports) {
    module.exports = api;
  }
  root.DD373Calc = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
